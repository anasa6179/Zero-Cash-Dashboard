ZERO DASHBOARD — ANDROID STUDIO PROJECT

Branding:
- App name: Zero Dashboard
- Splash logo: supplied Zero Cash logo
- Theme: blue and white
- Website loaded: https://dashboard.xeonprive.com/

Build the APK:
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose Open and select the ZeroDashboardAndroid folder.
4. Allow Gradle sync to finish (internet is needed for first sync).
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show a notification with the APK location.

Important:
- This is the Android Studio source project, not a precompiled APK.
- Test login, downloads, file uploads, external links, and any dashboard-specific features on a real device.
- External links are currently not loaded inside the app; they may need a browser-intent implementation depending on the website.
